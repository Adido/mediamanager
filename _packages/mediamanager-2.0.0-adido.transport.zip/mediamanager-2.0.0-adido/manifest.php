<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '---------------------------------------
Media Manager
---------------------------------------
Version: 0.2.5
Author: Sterc <modx@sterc.nl>
---------------------------------------

The media manager extra is providing the more demanding content manager with enterprise grade features

## Features
-  Fully responsive
- Built on jQuery and Bootstrap for easier future development
- Fully database driven
- Virtual categories, instead of folders to allow a file to be in multiple categories
- Tag support
- Version control for your media
- Image editing features, including resizing and cropping
- Ability to publish/unpublish media with reference-checking
- Support for TinyMCE, TV\'s, ContentBlocks
- Meta data for images out of the box: id, version, filename, version, author, dimensions (original + cropped image size), category, tags)
- Unlimited additional meta data (like TV\'s for images!)
- MODX ACL for removing/archiving images

## How do I get set up?
- Install the package through package management by uploading the latest version from the _packages folder.
- You have to enable the Media Manager per MediaSource. Go to the top-menu "Media" -> "Media Sources" -> "Create property" and set the Textfield value to "1"
- Now enable it per user by editing a user: "Manage" -> "Users" -> Edit a user -> "Settings" -> "Create new" and set the key and/or name to "media_sources_id" and set the value to the ID of the Media Source you just enabled.

That\'s it, have fun!

## Beta
Please note that this manager is BETA. Please create your issues in Github or create Pull Requests. Any questions? Email us at modx@sterc.nl',
    'changelog' => 'Changelog for MediaManager.

MediaManager (unreleased, -adido)
====================================
- Requires PHP 8.1 or later, for every site. Older PHP versions are no longer supported.
- Add support for S3 media sources (sources.modS3MediaSource), through Flysystem and the AWS SDK, bundled with prefixed namespaces
- Add system settings mediamanager.cache_path and mediamanager.cache_url for the thumbnail cache of S3 sources
- Add media source property mediamanagerS3ObjectAclEnabled, to disable ACLs on S3 sources whose bucket doesn\'t support them
- Thumbnails are created when a file is uploaded, cropped or copied, instead of when first viewed
- Thumbnails are created from the file\'s id, instead of a path, which closes a path traversal issue in the thumbnail processor
- Delete a PDF\'s preview when the file is deleted
- Copy to source now registers the copy against the source it was copied to
- Fix file URLs of media sources with an empty or "/" base URL
- Fix file versions not being created when renaming a file uploaded in an earlier month
- Fix the TV input preview when typing a file id
- ContentBlocks image inputs use the dimensions stored for a file. S3 files without stored dimensions use 400x400
- New TV input placeholder {$url}, with the file\'s URL. {$path} is unchanged for local files, and is the file\'s URL for S3 files

MediaManager 0.3.3
====================================
- Add custom plugin events:
    MediaManagerFileArchived,
    MediaManagerFileDeleted,
    MediaManagerFileVersionChanged,
    MediaManagerFilesArchived,
    MediaManagerVersionChanged

MediaManager 0.3.2
====================================
- Replace acute symbols with single quotes in lexicon files (fixes #54)
- Fix mediamanager styling when used in popup (fixes #55)
- Add support for MODX3 (PR #53, thanks to rtripault)
- Fix category parents visibility in categories dropdown (fixes #57)
- Add image_source as required field for licensing (fixes #58)

MediaManager 0.3.1
====================================
- Fixed Metadata required fields validation message shows key instead of label value #52
- Fixed ACLs - Mediasource and User Permissions #51
- Improved Archiving and Replacing visual interface confusing #50
- Fixed Content Blocks Image Gallery type not saving link in database #47

MediaManager 0.3.0
====================================
- Escape new reserved words for MySQL 8+ (#38)
- Added indexes on database columns
- Improved error handling during file upload and file edit
- Added option to add predefined set of meta fields
- Added optional image licensing feature
- PHP 8 compatibility fixes
- Fixed compatibility with recent version of TinyMCE RTE using the callback

MediaManager 0.2.9
====================================
- Fix load modPhpThumb for previews (#15)

MediaManager 0.2.8
====================================
- Fix replacing images used in ContentBlocks fields (#31)
- Add linked resource ID in preview popup (#24)

MediaManager 0.2.7
====================================
- Fix Archive & Replace feature for TV and ContentBlocks field

MediaManager 0.2.6
====================================
- Check file existing on archive and unarchive (#27)
- Delete versions and thumbnails for deleted files (#33)
- Fix setting value if TV not found (#34)

MediaManager 0.2.5
====================================
- Fix after adding images to pages, no link reference getting shown in backend GUI (#24)
- Fix MODX Resource / Elements visibility toggle button not working (#26)
- Fix deleting an image was not successful (#27)
- Fix when opening the preview window on an image, MODX logs some errors (#28)
- Fix available sizes is not being populated with information (#29)

MediaManager 0.2.4
====================================
- Fix thumbnail generation (#15)
- Fix some styling issues (#16)
- Fix category creation (#17)
- Fix tag creation (#18)
- Fix uploading files error (#19)
- Add metadata template (#21)

MediaManager 0.2.3
====================================
- SVG previews are now shown in the mediamanager
- Added system settings for the maximum allowable file upload sizes

MediaManager 0.2.2
====================================
- Replaced JQuery lazyload with native lazyload
- Fixed imagickloaded check and added fallback for pdf previews
- Fixed issue with the mediamanager component height

MediaManager 0.2.1
====================================
- Added custom MIGX renderer "MediaManager.MIGX_Image_Renderer"
- Fixed generated share link
- Fixed bulk delete
- Added image input field for ContentBlocks
- Added support for Redactor 3.0
- Improved search, now searches in both file name and file id columns
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f84e1230771d3f65e32341c3fe88ff40',
      'native_key' => 'mediamanager',
      'filename' => 'modNamespace/0993876594c316649fd452cbf030bf54.vehicle',
      'namespace' => 'mediamanager',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a40c8f416172a35d1abf72f146f6bec1',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'modSystemSetting/dec9b91ad76a91d35317f1a3d38d6cf8.vehicle',
      'namespace' => 'mediamanager',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c5d7e291841c982a9c66480db07248ea',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'modSystemSetting/3a16de6b3e5aed35480bdf2bf0edc0f5.vehicle',
      'namespace' => 'mediamanager',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d0c3635e43280de42f2cb76d4a31e72',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'modSystemSetting/d354fe3bb314fc417696270def299025.vehicle',
      'namespace' => 'mediamanager',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c064d2d86df95f5853833e53fbe569f',
      'native_key' => 'mediamanager.max_file_size',
      'filename' => 'modSystemSetting/047ce5a97fe9460cd19a45493e88f6f8.vehicle',
      'namespace' => 'mediamanager',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b1593a7a3d9f555d176f4fc451173cc',
      'native_key' => 'mediamanager.max_file_size_images',
      'filename' => 'modSystemSetting/5be9e0f11381af170254724f87cc9330.vehicle',
      'namespace' => 'mediamanager',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '383bd37d3ae8491f22fc6b8000825925',
      'native_key' => 'mediamanager.cache_path',
      'filename' => 'modSystemSetting/ccf84f7fc46323fe8901693db04dad18.vehicle',
      'namespace' => 'mediamanager',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a24d637d6450643fe91c713bf4896214',
      'native_key' => 'mediamanager.cache_url',
      'filename' => 'modSystemSetting/0cdb223e34711c8c09d38a671e9ebf15.vehicle',
      'namespace' => 'mediamanager',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '7fddb0c2b63570f9a9dcf72163e4f7e2',
      'native_key' => NULL,
      'filename' => 'modCategory/d13818895e3e7e1c4e98f14bbb9c7aa3.vehicle',
      'namespace' => 'mediamanager',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '47f56cefc541a42e31344180b9e87062',
      'native_key' => 'mediamanager',
      'filename' => 'modMenu/2e9c48003b07745d1d5fe0d6f52a0717.vehicle',
      'namespace' => 'mediamanager',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '9549d39e45cf3998a983260a742c7a25',
      'native_key' => 'mediamanager.categories',
      'filename' => 'modMenu/ecd1c215c837c1454d07383221610af7.vehicle',
      'namespace' => 'mediamanager',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ce0c81d648ac43e388370e6baf31dfdd',
      'native_key' => 'mediamanager.tags',
      'filename' => 'modMenu/013369ee715908b5954639e4a0bf3af2.vehicle',
      'namespace' => 'mediamanager',
    ),
  ),
);