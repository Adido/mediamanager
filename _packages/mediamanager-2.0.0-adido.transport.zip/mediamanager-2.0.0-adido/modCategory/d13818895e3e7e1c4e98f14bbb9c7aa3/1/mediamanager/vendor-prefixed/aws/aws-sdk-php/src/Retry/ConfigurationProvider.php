<?php
namespace Sterc\MediaManager\Vendor\Aws\Retry;

use Sterc\MediaManager\Vendor\Aws\AbstractConfigurationProvider;
use Sterc\MediaManager\Vendor\Aws\CacheInterface;
use Sterc\MediaManager\Vendor\Aws\Configuration\ConfigurationResolver;
use Sterc\MediaManager\Vendor\Aws\ConfigurationProviderInterface;
use Sterc\MediaManager\Vendor\Aws\Retry\Exception\ConfigurationException;
use Sterc\MediaManager\Vendor\Aws\Retry\V3\OptIn;
use Sterc\MediaManager\Vendor\GuzzleHttp\Promise;
use Sterc\MediaManager\Vendor\GuzzleHttp\Promise\PromiseInterface;

/**
 * A configuration provider is a function that returns a promise that is
 * fulfilled with a {@see \Sterc\MediaManager\Vendor\Aws\Retry\ConfigurationInterface}
 * or rejected with an {@see \Sterc\MediaManager\Vendor\Aws\Retry\Exception\ConfigurationException}.
 *
 * <code>
 * use Sterc\MediaManager\Vendor\Aws\Sts\RegionalEndpoints\ConfigurationProvider;
 * $provider = ConfigurationProvider::defaultProvider();
 * // Returns a ConfigurationInterface or throws.
 * $config = $provider()->wait();
 * </code>
 *
 * Configuration providers can be composed to create configuration using
 * conditional logic that can create different configurations in different
 * environments. You can compose multiple providers into a single provider using
 * {@see \Sterc\MediaManager\Vendor\Aws\Retry\ConfigurationProvider::chain}. This function
 * accepts providers as variadic arguments and returns a new function that will
 * invoke each provider until a successful configuration is returned.
 *
 * <code>
 * // First try an INI file at this location.
 * $a = ConfigurationProvider::ini(null, '/path/to/file.ini');
 * // Then try an INI file at this location.
 * $b = ConfigurationProvider::ini(null, '/path/to/other-file.ini');
 * // Then try loading from environment variables.
 * $c = ConfigurationProvider::env();
 * // Combine the three providers together.
 * $composed = ConfigurationProvider::chain($a, $b, $c);
 * // Returns a promise that is fulfilled with a configuration or throws.
 * $promise = $composed();
 * // Wait on the configuration to resolve.
 * $config = $promise->wait();
 * </code>
 */
class ConfigurationProvider extends AbstractConfigurationProvider
    implements ConfigurationProviderInterface
{
    const DEFAULT_MAX_ATTEMPTS = 3;
    const DEFAULT_MODE = 'legacy';
    const ENV_MAX_ATTEMPTS = 'AWS_MAX_ATTEMPTS';
    const ENV_MODE = 'AWS_RETRY_MODE';
    const ENV_PROFILE = 'AWS_PROFILE';
    const INI_MAX_ATTEMPTS = 'max_attempts';
    const INI_MODE = 'retry_mode';

    public static $cacheKey = 'aws_retries_config';

    protected static $interfaceClass = ConfigurationInterface::class;
    protected static $exceptionClass = ConfigurationException::class;

    /**
     * Create a default config provider that resolves the retry mode and
     * max attempts independently. Each value is read from its environment
     * variable, then from the profile selected by AWS_PROFILE (or "default")
     * in the shared config file (AWS_CONFIG_FILE, defaulting to
     * ~/.aws/config), and failing those falls back to its default.
     *
     * This provider is automatically wrapped in a memoize function that caches
     * previously provided config options.
     *
     * @param array $config
     *
     * @return callable
     */
    public static function defaultProvider(array $config = [])
    {
        $memo = self::memoize(function () use ($config) {
            return Promise\Create::promiseFor(
                new Configuration(
                    self::resolveMode($config),
                    self::resolveMaxAttempts($config) ?? self::DEFAULT_MAX_ATTEMPTS
                )
            );
        });

        if (isset($config['retries'])
            && $config['retries'] instanceof CacheInterface
        ) {
            return self::cache($memo, $config['retries'], self::$cacheKey);
        }

        return $memo;
    }

    /**
     * Provider that creates config from environment variables.
     *
     * @return callable
     */
    public static function env()
    {
        return function () {
            // Use config from environment variables, if available
            $mode = getenv(self::ENV_MODE);
            $maxAttempts = getenv(self::ENV_MAX_ATTEMPTS);
            $hasMode = $mode !== false && $mode !== '';
            $hasMaxAttempts = $maxAttempts !== false && $maxAttempts !== '';

            if ($hasMode || $hasMaxAttempts) {
                return Promise\Create::promiseFor(
                    new Configuration(
                        $hasMode ? $mode : self::getDefaultMode(),
                        $hasMaxAttempts ? $maxAttempts : self::DEFAULT_MAX_ATTEMPTS
                    ));
            }

            return self::reject('Could not find environment variable config'
                . ' in ' . self::ENV_MODE
                . ' or ' . self::ENV_MAX_ATTEMPTS);
        };
    }

    /**
     * Fallback config options when other sources are not set.
     *
     * @return callable
     */
    public static function fallback()
    {
        return function () {
            return Promise\Create::promiseFor(
                new Configuration(self::getDefaultMode(), self::DEFAULT_MAX_ATTEMPTS)
            );
        };
    }

    /**
     * Returns the default retry mode. Reflects the AWS_NEW_RETRIES_2026
     * opt-in: 'standard' when the env flag is set, 'legacy' otherwise.
     */
    public static function getDefaultMode(): string
    {
        return OptIn::isEnabled() ? 'standard' : self::DEFAULT_MODE;
    }

    /**
     * @internal Resolves retry_mode from AWS_RETRY_MODE, then the shared
     *           config file, then {@see self::getDefaultMode()}. The value
     *           is lowercased, matching {@see Configuration}.
     *
     * @param array $config Client arguments ('use_aws_shared_config_files').
     *
     * @return string
     */
    public static function resolveMode(array $config = []): string
    {
        $mode = ConfigurationResolver::resolve(
            self::INI_MODE,
            null,
            'string',
            $config
        );

        return $mode === null || $mode === ''
            ? self::getDefaultMode()
            : strtolower($mode);
    }

    /**
     * @internal Resolves max_attempts from AWS_MAX_ATTEMPTS, then the shared
     *           config file. Returns null when neither sets a value so each
     *           caller can apply its own default. The value is returned
     *           unvalidated; {@see Configuration} rejects invalid values.
     *
     * @param array $config Client arguments ('use_aws_shared_config_files').
     *
     * @return string|null
     */
    public static function resolveMaxAttempts(array $config = []): ?string
    {
        // Resolved as a string so an empty "max_attempts =" stays '' (unset)
        // rather than being coerced to 0.
        $maxAttempts = ConfigurationResolver::resolve(
            self::INI_MAX_ATTEMPTS,
            null,
            'string',
            $config
        );

        return $maxAttempts === '' ? null : $maxAttempts;
    }

    /**
     * Config provider that creates config using a config file whose location
     * is specified by an environment variable 'AWS_CONFIG_FILE', defaulting to
     * ~/.aws/config if not specified
     *
     * @param string|null $profile  Profile to use. If not specified will use
     *                              the "default" profile.
     * @param string|null $filename If provided, uses a custom filename rather
     *                              than looking in the default directory.
     *
     * @return callable
     */
    public static function ini(
        $profile = null,
        $filename = null
    ) {
        $filename = $filename ?: (self::getDefaultConfigFilename());
        $profile = $profile ?: (getenv(self::ENV_PROFILE) ?: 'default');

        return function () use ($profile, $filename) {
            if (!@is_readable($filename)) {
                return self::reject("Cannot read configuration from $filename");
            }
            $data = \Sterc\MediaManager\Vendor\Aws\parse_ini_file($filename, true);
            if ($data === false) {
                return self::reject("Invalid config file: $filename");
            }
            if (!isset($data[$profile])) {
                return self::reject("'$profile' not found in config file");
            }
            $hasMode = isset($data[$profile][self::INI_MODE])
                && $data[$profile][self::INI_MODE] !== '';
            $hasMaxAttempts = array_key_exists(
                self::INI_MAX_ATTEMPTS,
                $data[$profile]
            ) && $data[$profile][self::INI_MAX_ATTEMPTS] !== '';

            if (!$hasMode && !$hasMaxAttempts) {
                return self::reject("Required retry config values
                    not present in INI profile '{$profile}' ({$filename})");
            }

            $maxAttempts = $hasMaxAttempts
                ? $data[$profile][self::INI_MAX_ATTEMPTS]
                : self::DEFAULT_MAX_ATTEMPTS;

            return Promise\Create::promiseFor(
                new Configuration(
                    $hasMode
                        ? $data[$profile][self::INI_MODE]
                        : self::getDefaultMode(),
                    $maxAttempts
                )
            );
        };
    }

    /**
     * Unwraps a configuration object in whatever valid form it is in,
     * always returning a ConfigurationInterface object.
     *
     * @param  mixed $config
     * @return ConfigurationInterface
     * @throws \InvalidArgumentException
     */
    public static function unwrap($config)
    {
        if (is_callable($config)) {
            $config = $config();
        }
        if ($config instanceof PromiseInterface) {
            $config = $config->wait();
        }
        if ($config instanceof ConfigurationInterface) {
            return $config;
        }

        // An integer value for this config indicates the legacy 'retries'
        // config option, which is incremented to translate to max attempts
        if (is_int($config)) {
            return new Configuration('legacy', $config + 1);
        }

        if (is_array($config) && isset($config['mode'])) {
            $maxAttempts = isset($config['max_attempts'])
                ? $config['max_attempts']
                : self::DEFAULT_MAX_ATTEMPTS;
            return new Configuration($config['mode'], $maxAttempts);
        }

        throw new \InvalidArgumentException('Not a valid retry configuration'
            . ' argument.');
    }
}
