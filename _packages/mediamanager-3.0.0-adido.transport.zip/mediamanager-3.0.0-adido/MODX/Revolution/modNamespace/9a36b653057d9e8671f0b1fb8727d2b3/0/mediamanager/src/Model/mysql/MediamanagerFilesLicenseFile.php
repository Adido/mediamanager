<?php
namespace Sterc\MediaManager\Model\mysql;

use xPDO\xPDO;

class MediamanagerFilesLicenseFile extends \Sterc\MediaManager\Model\MediamanagerFilesLicenseFile
{

    public static $metaMap = array (
        'package' => 'Sterc\\MediaManager\\Model',
        'version' => NULL,
        'table' => 'mediamanager_files_license_file',
        'extends' => 'xPDO\\Om\\xPDOSimpleObject',
        'tableMeta' => 
        array (
            'engine' => 'InnoDB',
        ),
        'fields' => 
        array (
            'mediamanager_files_id' => 0,
            'license_id' => 0,
        ),
        'fieldMeta' => 
        array (
            'mediamanager_files_id' => 
            array (
                'dbtype' => 'int',
                'precision' => '10',
                'attributes' => 'unsigned',
                'phptype' => 'integer',
                'null' => false,
                'default' => 0,
                'index' => 'index',
            ),
            'license_id' => 
            array (
                'dbtype' => 'int',
                'precision' => '10',
                'attributes' => 'unsigned',
                'phptype' => 'integer',
                'null' => false,
                'default' => 0,
                'index' => 'index',
            ),
        ),
        'indexes' => 
        array (
            'mediamanager_files_id' => 
            array (
                'alias' => 'mediamanager_files_id',
                'primary' => false,
                'unique' => false,
                'type' => 'BTREE',
                'columns' => 
                array (
                    'mediamanager_files_id' => 
                    array (
                        'length' => '',
                        'collation' => 'A',
                        'null' => false,
                    ),
                ),
            ),
            'license_id' => 
            array (
                'alias' => 'license_id',
                'primary' => false,
                'unique' => false,
                'type' => 'BTREE',
                'columns' => 
                array (
                    'license_id' => 
                    array (
                        'length' => '',
                        'collation' => 'A',
                        'null' => false,
                    ),
                ),
            ),
        ),
        'aggregates' => 
        array (
            'File' => 
            array (
                'class' => 'Sterc\\MediaManager\\Model\\MediamanagerFiles',
                'local' => 'mediamanager_files_id',
                'foreign' => 'id',
                'cardinality' => 'one',
                'owner' => 'foreign',
            ),
            'License' => 
            array (
                'class' => 'Sterc\\MediaManager\\Model\\MediamanagerFilesLicense',
                'local' => 'license_id',
                'foreign' => 'id',
                'cardinality' => 'one',
                'owner' => 'foreign',
            ),
        ),
    );

}
