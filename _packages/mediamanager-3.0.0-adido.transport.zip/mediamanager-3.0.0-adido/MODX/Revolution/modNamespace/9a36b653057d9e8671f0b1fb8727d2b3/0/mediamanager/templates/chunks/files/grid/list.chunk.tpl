[[+breadcrumbs]]

[[+items]]

[[+pagination]]