<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# Media Manager for MODX [BETA]
![Media Manager version](https://img.shields.io/badge/version-3.0.0-brightgreen.svg)
![MODX Extra by Sterc](https://img.shields.io/badge/extra%20by-sterc-ff69b4.svg)

The Media Manager is a MODX Extra replacing the default Media Browser with an enterprise-grade media management solution, an initiative by [SEDA](https://seda.digital/) and [Sterc](https://www.sterc.com).

## Requirements

| MediaManager version | MODX version | PHP version |
|---|---|---|
| 3.x and later | MODX 3.x | PHP 8.1+ |
| 0.3.x and earlier | MODX 2.x | PHP 7.x / 8.0 |

Upgrading from MODX 2? See [UPGRADING.md](UPGRADING.md).

## Features
- Fully responsive
- Built on jQuery and Bootstrap for easier future development
- Fully database driven
- Virtual categories, instead of folders to allow a file to be in multiple categories
- Tag support
- Version control for your media
- Image editing features, including resizing and cropping
- Ability to publish/unpublish media with reference-checking
- Support for TinyMCE, Redactor 3.0, TV\'s, ContentBlocks
- Meta data for images out of the box: id, version, filename, version, author, dimensions (original + cropped image size), category, tags)
- Unlimited additional meta data (like TV\'s for images!)
- MODX ACL for removing/archiving images
- Attaching licenses to images including expiration dates

## Migrating from the default media browser
A migration tool is not yet available. You will not loose your old images, but they also will not show up in the new media browser.

## Installation
1. Install the package through package management by uploading the latest version from the _packages folder.
2. You have to enable the Media Manager per MediaSource. Go to the top-menu "Media" -> "Media Sources" -> "Create property": Name=mediamanagerSource, Type=Textfield, Value=1
3. Now enable it per user by editing a user: "Manage" -> "Users" -> Edit a user -> "Settings" -> "Create new" and set the key and/or name to "media_sources_id" and set the value to the ID of the Media Source you just enabled.

That\'s it, have fun!

## Redactor implementation
If you like to implement the mediamanager for Redactor 3.0, please take the following steps:
* Add the following path to the system setting **redactor.js**: `/assets/components/mediamanager/js/inputs/redactor_mediamanager.js`
* Go to the configuration set of redactor and add `mediamanager` under Miscellaneous --> Additional plugins
* Add `mediamanager` in the Toolbar Buttons list in the Toolbar tab

## Media Source settings

The following settings can be defined on media source level.

| Key                                | Description                                                                                                    | Example value                                                                                                                                                 |
|------------------------------------|----------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| mediamanagerSource                 | Determine if media source should use MediaManager.                                                             | 1                                                                                                                                                             |
| mediamanagerMeta                   | Set default meta fields and determine if fields should be marked as required or not.                           | [{"key":"author", "label":"Author", "required": true}, {"key":"photographer", "label":"Photographer", "required": true}, {"key": "editor", "label":"Editor"}] |
| mediamanagerLicenseEnabled         | Determine if license fields should be used.                                                                    | 1                                                                                                                                                             |
| mediamanagerLicenseSources         | Set available license sources with optional expiry date.                                                      | [{"key": "local", "label": "Local"},{"key": "getty_images", "label": "Getty Images", "expireson":  "24-03-2023"}]                                             |
| mediamanagerLicenseTestFrequencies | Frequencies (in days) to send out a notification email before image sources and/or images are about to expire. | ["14 days", "5 days", "1 days"]                                                                                                                               |
| mediamanagerLicenseTestRecipients  | Recipient emails that should receive image source/image license expiry notifications.                          | john@example.com,johndoe@example.com                                                                                                                          |


## Cron jobs
Run Cron jobs by calling the cron script and by specifying the jobs you\'d like to run (comma delimited).

```
php /assets/components/mediamanager/cronjob/cron.php --jobs=TestImageSourceValidity,TestImageValidity
```

| Job                     | Description                                                                   |
|-------------------------|-------------------------------------------------------------------------------|
| TestImageValidity       | Job which checks image expiry and sends notification emails if needed.        |
| TestImageSourceValidity | Job which checks image source expiry and sends notification emails if needed. |


## BETA BETA
Please note that this manager is BETA. Please create your issues in Github or create Pull Requests. Any questions? Email us at modx@sterc.nl
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '1f3071ba3bb19a8c995930fabe8b68d3',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modNamespace/9a36b653057d9e8671f0b1fb8727d2b3.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '161e415313051ee3399324218cf4353a',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'MODX/Revolution/modSystemSetting/9d9dfd89f8424aca62546a352bd5a2e8.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0102244f4f676621ba6cb93f86f445d8',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'MODX/Revolution/modSystemSetting/94f9bdc52ad64f72212859624483ba0d.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6f3e5f7890c3368bf3a4f829c82129c0',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/e1efa4ff73ab420059fdd28e751e93aa.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '065571b2826ce3e45c3845045704bd63',
      'native_key' => 'mediamanager.max_file_size',
      'filename' => 'MODX/Revolution/modSystemSetting/e49184b6c10befa62368bf15b4c99e85.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c174932c6fdfb89188c1f54f260e1cac',
      'native_key' => 'mediamanager.max_file_size_images',
      'filename' => 'MODX/Revolution/modSystemSetting/f3e9d4da840e605b5d325d8e5f249a52.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'f7b6a9bf12b872dee761da605f1542a6',
      'native_key' => 'f7b6a9bf12b872dee761da605f1542a6',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/f9bd7e76e6f56b84c41e56b0c0469244.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '4e3c6a75ebe80e23d4fedba55911b00f',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modMenu/50f5aa4df3317fa6828ff05d48f657ff.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '1bc317ae0dcc3d3198e67ca31acb18b8',
      'native_key' => 'mediamanager.categories',
      'filename' => 'MODX/Revolution/modMenu/b43da765c0e8433869c8de47dac4e941.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '731b47c23bcf32427aa776066d29822f',
      'native_key' => 'mediamanager.tags',
      'filename' => 'MODX/Revolution/modMenu/5dcb344ccc8f206731d5a95fe9331303.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '111301dd590a232199ecb3341c467ebf',
      'native_key' => '111301dd590a232199ecb3341c467ebf',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/b74d6db92b887c2a47a3c27e9d37113b.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'f90b6d9d04e5777a58fc805652001dd9',
      'native_key' => 'f90b6d9d04e5777a58fc805652001dd9',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/e1e5a92b945e25db92389eb411540a1a.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'f9ddf9aea5b84e725d0c0011c70c9804',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/ef13643665ca6b9dbe8afd99311366e8.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'bab8ce7c2db4fe774e519d77da253fa4',
      'native_key' => 'bab8ce7c2db4fe774e519d77da253fa4',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/a2376f9e2799c95a8bfb4df395c4c991.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '591cc2e84a7151d491afc11de8c3c0d6',
      'native_key' => '591cc2e84a7151d491afc11de8c3c0d6',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/078702f6944b4b11626f4c1cb535831c.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '8dc0ceecf04e2ec5e3899333b501d680',
      'native_key' => '8dc0ceecf04e2ec5e3899333b501d680',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/847b13a5f4136301c003df5258211c92.vehicle',
    ),
  ),
);