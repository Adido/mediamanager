<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# Media Manager for MODX [BETA]
![Media Manager version](https://img.shields.io/badge/version-3.0.0-brightgreen.svg)
![MODX Extra by Sterc](https://img.shields.io/badge/extra%20by-sterc-ff69b4.svg)

The Media Manager is a MODX Extra replacing the default Media Browser with an enterprise-grade media management solution, an initiative by [SEDA](https://seda.digital/) and [Sterc](https://www.sterc.com).

## Requirements

| MediaManager version | MODX version | PHP version |
|---|---|---|
| 3.x and later | MODX 3.x | PHP 8.1+ |
| 0.3.x and earlier | MODX 2.x | PHP 7.x / 8.0 |

Upgrading from MODX 2? See [UPGRADING.md](UPGRADING.md).

## Features
- Fully responsive
- Built on jQuery and Bootstrap for easier future development
- Fully database driven
- Virtual categories, instead of folders to allow a file to be in multiple categories
- Tag support
- Version control for your media
- Image editing features, including resizing and cropping
- Ability to publish/unpublish media with reference-checking
- Support for TinyMCE, Redactor 3.0, TV\'s, ContentBlocks
- Meta data for images out of the box: id, version, filename, version, author, dimensions (original + cropped image size), category, tags)
- Unlimited additional meta data (like TV\'s for images!)
- MODX ACL for removing/archiving images
- Attaching licenses to images including expiration dates

## Migrating from the default media browser
A migration tool is not yet available. You will not loose your old images, but they also will not show up in the new media browser.

## Installation
1. Install the package through package management by uploading the latest version from the _packages folder.
2. You have to enable the Media Manager per MediaSource. Go to the top-menu "Media" -> "Media Sources" -> "Create property": Name=mediamanagerSource, Type=Textfield, Value=1
3. Now enable it per user by editing a user: "Manage" -> "Users" -> Edit a user -> "Settings" -> "Create new" and set the key and/or name to "media_sources_id" and set the value to the ID of the Media Source you just enabled.

That\'s it, have fun!

## Redactor implementation
If you like to implement the mediamanager for Redactor 3.0, please take the following steps:
* Add the following path to the system setting **redactor.js**: `/assets/components/mediamanager/js/inputs/redactor_mediamanager.js`
* Go to the configuration set of redactor and add `mediamanager` under Miscellaneous --> Additional plugins
* Add `mediamanager` in the Toolbar Buttons list in the Toolbar tab

## Media Source settings

The following settings can be defined on media source level.

| Key                                | Description                                                                                                    | Example value                                                                                                                                                 |
|------------------------------------|----------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| mediamanagerSource                 | Determine if media source should use MediaManager.                                                             | 1                                                                                                                                                             |
| mediamanagerMeta                   | Set default meta fields and determine if fields should be marked as required or not.                           | [{"key":"author", "label":"Author", "required": true}, {"key":"photographer", "label":"Photographer", "required": true}, {"key": "editor", "label":"Editor"}] |
| mediamanagerLicenseEnabled         | Determine if license fields should be used.                                                                    | 1                                                                                                                                                             |
| mediamanagerLicenseSources         | Set available license sources with optional expiry date.                                                      | [{"key": "local", "label": "Local"},{"key": "getty_images", "label": "Getty Images", "expireson":  "24-03-2023"}]                                             |
| mediamanagerLicenseTestFrequencies | Frequencies (in days) to send out a notification email before image sources and/or images are about to expire. | ["14 days", "5 days", "1 days"]                                                                                                                               |
| mediamanagerLicenseTestRecipients  | Recipient emails that should receive image source/image license expiry notifications.                          | john@example.com,johndoe@example.com                                                                                                                          |


## Cron jobs
Run Cron jobs by calling the cron script and by specifying the jobs you\'d like to run (comma delimited).

```
php /assets/components/mediamanager/cronjob/cron.php --jobs=TestImageSourceValidity,TestImageValidity
```

| Job                     | Description                                                                   |
|-------------------------|-------------------------------------------------------------------------------|
| TestImageValidity       | Job which checks image expiry and sends notification emails if needed.        |
| TestImageSourceValidity | Job which checks image source expiry and sends notification emails if needed. |


## BETA BETA
Please note that this manager is BETA. Please create your issues in Github or create Pull Requests. Any questions? Email us at modx@sterc.nl
',
    'setup-options' => 'mediamanager-3.0.0-adido/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'c3ccebbc004576b2da18d6fc5535bba8',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modNamespace/94ded116f8f55f4769a9bc61afb58a41.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60dacc8fbe4dbd7031e4d56852964611',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'MODX/Revolution/modSystemSetting/e3c015f9aa4384ac63c9784231c9af71.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '70582a6c0e8f147755c874aa8b95017e',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'MODX/Revolution/modSystemSetting/f135f50c8f4fe03eb86154518252c286.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2ef953408af9d02711042be285034d1b',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/a30fbb3e67502240153cbec23c2fdd9c.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2dd9433ab61a068f7644b29aea4f2fbc',
      'native_key' => 'mediamanager.max_file_size',
      'filename' => 'MODX/Revolution/modSystemSetting/971c19fee2d63edaa608eb31880fa632.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7e491ccdfd24f340912bfde5d65d7995',
      'native_key' => 'mediamanager.max_file_size_images',
      'filename' => 'MODX/Revolution/modSystemSetting/3d86c129f524442e7ebd8e7c57cabd84.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'fc767208551b09569f81b812f35c5cd1',
      'native_key' => 'fc767208551b09569f81b812f35c5cd1',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/a56992bd67720ff6a8f17ed25b374f78.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '722b930da2671891092f8f90e7186055',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modMenu/acb8552ad5ca5a6d343d097a2bed6fd7.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'e1177302285613a9633ab8a2d0a0dc1e',
      'native_key' => 'mediamanager.categories',
      'filename' => 'MODX/Revolution/modMenu/addec9bffed926e123333ce65a3a8d58.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '563dc452337dbfd87375df560d0fa46c',
      'native_key' => 'mediamanager.tags',
      'filename' => 'MODX/Revolution/modMenu/69e3be88f3050efd7d84d47dd9ff5677.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '734aad71861950e552d328417610e7ba',
      'native_key' => '734aad71861950e552d328417610e7ba',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/81a7e521b677588d6098b6dc117fa160.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'aa983db7f770758faf1c87e1c6f6db42',
      'native_key' => 'aa983db7f770758faf1c87e1c6f6db42',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/927b0e1e741a4645fef5d13495528ed3.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'a452b06fe51b43c58d4c1a8edde53bef',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/0ed9f1406d7d0c928868ed9b10720d2d.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '1407052fed6f8985dc8b705d19272ebd',
      'native_key' => '1407052fed6f8985dc8b705d19272ebd',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/37046c6cb6c7177fac72508f2b41e7ad.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'd45bfc722c70976961f1fd5f8cc5c382',
      'native_key' => 'd45bfc722c70976961f1fd5f8cc5c382',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/e341a55b5ac18aad5f0d588e1c15db2d.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '2b232b7475afd74577fb368a405b6193',
      'native_key' => '2b232b7475afd74577fb368a405b6193',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/b4e727c4a364db286265c4376bba6291.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'c4abefece47348da5064d6eb1f0b7f3b',
      'native_key' => 'c4abefece47348da5064d6eb1f0b7f3b',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/ef71c530cd138bcc99a0e05975a545d7.vehicle',
    ),
  ),
);