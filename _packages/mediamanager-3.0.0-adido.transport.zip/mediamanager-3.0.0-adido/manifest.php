<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '# Media Manager for MODX [BETA]
![Media Manager version](https://img.shields.io/badge/version-3.0.0-brightgreen.svg)
![MODX Extra by Sterc](https://img.shields.io/badge/extra%20by-sterc-ff69b4.svg)

The Media Manager is a MODX Extra replacing the default Media Browser with an enterprise-grade media management solution, an initiative by [SEDA](https://seda.digital/) and [Sterc](https://www.sterc.com).

## Requirements

| MediaManager version | MODX version | PHP version |
|---|---|---|
| 3.x and later | MODX 3.x | PHP 8.1+ |
| 0.3.x and earlier | MODX 2.x | PHP 7.x / 8.0 |

Upgrading from MODX 2? See [UPGRADING.md](UPGRADING.md).

## Features
- Fully responsive
- Built on jQuery and Bootstrap for easier future development
- Fully database driven
- Virtual categories, instead of folders to allow a file to be in multiple categories
- Tag support
- Version control for your media
- Image editing features, including resizing and cropping
- Ability to publish/unpublish media with reference-checking
- Support for TinyMCE, Redactor 3.0, TV\'s, ContentBlocks
- Meta data for images out of the box: id, version, filename, version, author, dimensions (original + cropped image size), category, tags)
- Unlimited additional meta data (like TV\'s for images!)
- MODX ACL for removing/archiving images
- Attaching licenses to images including expiration dates

## Migrating from the default media browser
A migration tool is not yet available. You will not loose your old images, but they also will not show up in the new media browser.

## Installation
1. Install the package through package management by uploading the latest version from the _packages folder.
2. You have to enable the Media Manager per MediaSource. Go to the top-menu "Media" -> "Media Sources" -> "Create property": Name=mediamanagerSource, Type=Textfield, Value=1
3. Now enable it per user by editing a user: "Manage" -> "Users" -> Edit a user -> "Settings" -> "Create new" and set the key and/or name to "media_sources_id" and set the value to the ID of the Media Source you just enabled.

That\'s it, have fun!

## Redactor implementation
If you like to implement the mediamanager for Redactor 3.0, please take the following steps:
* Add the following path to the system setting **redactor.js**: `/assets/components/mediamanager/js/inputs/redactor_mediamanager.js`
* Go to the configuration set of redactor and add `mediamanager` under Miscellaneous --> Additional plugins
* Add `mediamanager` in the Toolbar Buttons list in the Toolbar tab

## Media Source settings

The following settings can be defined on media source level.

| Key                                | Description                                                                                                    | Example value                                                                                                                                                 |
|------------------------------------|----------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| mediamanagerSource                 | Determine if media source should use MediaManager.                                                             | 1                                                                                                                                                             |
| mediamanagerMeta                   | Set default meta fields and determine if fields should be marked as required or not.                           | [{"key":"author", "label":"Author", "required": true}, {"key":"photographer", "label":"Photographer", "required": true}, {"key": "editor", "label":"Editor"}] |
| mediamanagerLicenseEnabled         | Determine if license fields should be used.                                                                    | 1                                                                                                                                                             |
| mediamanagerLicenseSources         | Set available license sources with optional expiry date.                                                      | [{"key": "local", "label": "Local"},{"key": "getty_images", "label": "Getty Images", "expireson":  "24-03-2023"}]                                             |
| mediamanagerLicenseTestFrequencies | Frequencies (in days) to send out a notification email before image sources and/or images are about to expire. | ["14 days", "5 days", "1 days"]                                                                                                                               |
| mediamanagerLicenseTestRecipients  | Recipient emails that should receive image source/image license expiry notifications.                          | john@example.com,johndoe@example.com                                                                                                                          |


## Cron jobs
Run Cron jobs by calling the cron script and by specifying the jobs you\'d like to run (comma delimited).

```
php /assets/components/mediamanager/cronjob/cron.php --jobs=TestImageSourceValidity,TestImageValidity
```

| Job                     | Description                                                                   |
|-------------------------|-------------------------------------------------------------------------------|
| TestImageValidity       | Job which checks image expiry and sends notification emails if needed.        |
| TestImageSourceValidity | Job which checks image source expiry and sends notification emails if needed. |


## BETA BETA
Please note that this manager is BETA. Please create your issues in Github or create Pull Requests. Any questions? Email us at modx@sterc.nl
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'cba53a18ad934298dccb60c733e3394e',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modNamespace/4451010d1ed61cf8a0338c5615c883d9.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '70bfbbec216dc01915b13321665b33b7',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'MODX/Revolution/modSystemSetting/a195f1cfb461137dcf370c25df281439.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7962b4ec21456b1f1e168ee4207842ab',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'MODX/Revolution/modSystemSetting/118f9758f378318502673a36e9fc00dc.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8e58561fecfb06578af3809f32cf2e30',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/96d65fe8834d9fadd50f29978985e430.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd62a4e042c511262e3cf0e7e511a45ab',
      'native_key' => 'mediamanager.max_file_size',
      'filename' => 'MODX/Revolution/modSystemSetting/796d0160ec0567439ab046d868b462f7.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '21881071e26c8486e590f0be20f815ca',
      'native_key' => 'mediamanager.max_file_size_images',
      'filename' => 'MODX/Revolution/modSystemSetting/59eacac163ca433591a854a0bb5568ca.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '5f93409ccc59a82186c689860aa1be17',
      'native_key' => '5f93409ccc59a82186c689860aa1be17',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/63e8c3ea1b75d52a605254a693ce6a13.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '30dec15413b5833042047d0c891d23b8',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modMenu/5d84431f8befed6516e02e1c0bd1ad1a.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'cd389595b04e7545782c47b59e636e3d',
      'native_key' => 'mediamanager.categories',
      'filename' => 'MODX/Revolution/modMenu/29f8bd8376f61fb14216f0b43b72cd8f.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '7d683af63a78ab48d3be93c50aaf60f8',
      'native_key' => 'mediamanager.tags',
      'filename' => 'MODX/Revolution/modMenu/a5d894699fd21ab0ea996555df7617e3.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '17322249b0ca39c443dc6e9e62e9ab69',
      'native_key' => '17322249b0ca39c443dc6e9e62e9ab69',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/3d2c87adf5cd4733db24e564ce68fe68.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '0e44666d935ceeb4aef642982f1ba5d4',
      'native_key' => '0e44666d935ceeb4aef642982f1ba5d4',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/402867b2766a30f2e670c65ee596f4ab.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => 'ccd5ccc352304882959ca60eecae7ae0',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/bd640c0b37a7d81f76351182c6ba62b9.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'a47c9e7897fde33822f00fbb69e9c4c5',
      'native_key' => 'a47c9e7897fde33822f00fbb69e9c4c5',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/2d1b10a57232947092bd744462ac4bb7.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '13afc14385cbcfa8160e97ece38fdfb4',
      'native_key' => '13afc14385cbcfa8160e97ece38fdfb4',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/c2f9d3746c8c05be7e08115c5aea9dc3.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '430040b02e51a8567cb387cb69d13a89',
      'native_key' => '430040b02e51a8567cb387cb69d13a89',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/d389231063abb6cd83551318c34f7a1c.vehicle',
    ),
  ),
);