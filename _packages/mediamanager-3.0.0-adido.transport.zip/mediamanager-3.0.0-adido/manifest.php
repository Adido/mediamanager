<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => '---------------------------------------
Media Manager
---------------------------------------
Version: 3.0.0-adido
Author: Sterc <modx@sterc.nl>
---------------------------------------

The media manager extra is providing the more demanding content manager with enterprise grade features

## Requirements
- MODX 3.x
- PHP 8.1+

## Features
-  Fully responsive
- Built on jQuery and Bootstrap for easier future development
- Fully database driven
- Virtual categories, instead of folders to allow a file to be in multiple categories
- Tag support
- Version control for your media
- Image editing features, including resizing and cropping
- Ability to publish/unpublish media with reference-checking
- Support for TinyMCE, Redactor 3.0, TV\'s, ContentBlocks
- Meta data for images out of the box: id, version, filename, version, author, dimensions (original + cropped image size), category, tags)
- Unlimited additional meta data (like TV\'s for images!)
- MODX ACL for removing/archiving images
- Attaching licenses to images including expiration dates

## How do I get set up?
- Install the package through package management by uploading the latest version from the _packages folder.
- You have to enable the Media Manager per MediaSource. Go to the top-menu "Media" -> "Media Sources" -> "Create property": Name=mediamanagerSource, Type=Textfield, Value=1
- Now enable it per user by editing a user: "Manage" -> "Users" -> Edit a user -> "Settings" -> "Create new" and set the key and/or name to "media_sources_id" and set the value to the ID of the Media Source you just enabled.

That\'s it, have fun!

## Media Source settings
The following settings can be defined on media source level:
- mediamanagerSource: Determine if media source should use MediaManager. Example: 1
- mediamanagerMeta: Set default meta fields and determine if fields should be marked as required or not. Example: [{"key":"author", "label":"Author", "required": true}]
- mediamanagerLicenseEnabled: Determine if license fields should be used. Example: 1
- mediamanagerLicenseSources: Set available license sources with optional expiry date. Example: [{"key": "local", "label": "Local"},{"key": "getty_images", "label": "Getty Images", "expireson": "24-03-2023"}]
- mediamanagerLicenseTestFrequencies: Frequencies (in days) to send out a notification email before image sources and/or images are about to expire. Example: ["14 days", "5 days", "1 days"]
- mediamanagerLicenseTestRecipients: Recipient emails that should receive image source/image license expiry notifications. Example: john@example.com,johndoe@example.com

## Cron jobs
Run Cron jobs by calling the cron script and by specifying the jobs you\'d like to run (comma delimited):

php /assets/components/mediamanager/cronjob/cron.php --jobs=TestImageSourceValidity,TestImageValidity

- TestImageValidity: Job which checks image expiry and sends notification emails if needed.
- TestImageSourceValidity: Job which checks image source expiry and sends notification emails if needed.

## Beta
Please note that this manager is BETA. Please create your issues in Github or create Pull Requests. Any questions? Email us at modx@sterc.nl',
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'changelog' => 'Changelog for MediaManager.

MediaManager 3.0.0-adido
====================================
- Upgraded to MODX 3 (requires PHP 8.1+)
- Rewrote build tooling for GPM 3 (_build/gpm.yml)
- Migrated all classes to the Sterc\\MediaManager namespace (PSR-4, under src/)
- Replaced $modx->getService(\'mediamanager\', ...) with $modx->services->get(\'mediamanager\')
- Added temporary class aliases for old unqualified class names (see include/deprecated.php)

MediaManager 0.3.3
====================================
- Add custom plugin events:
    MediaManagerFileArchived,
    MediaManagerFileDeleted,
    MediaManagerFileVersionChanged,
    MediaManagerFilesArchived,
    MediaManagerVersionChanged

MediaManager 0.3.2
====================================
- Replace acute symbols with single quotes in lexicon files (fixes #54)
- Fix mediamanager styling when used in popup (fixes #55)
- Add support for MODX3 (PR #53, thanks to rtripault)
- Fix category parents visibility in categories dropdown (fixes #57)
- Add image_source as required field for licensing (fixes #58)

MediaManager 0.3.1
====================================
- Fixed Metadata required fields validation message shows key instead of label value #52
- Fixed ACLs - Mediasource and User Permissions #51
- Improved Archiving and Replacing visual interface confusing #50
- Fixed Content Blocks Image Gallery type not saving link in database #47

MediaManager 0.3.0
====================================
- Escape new reserved words for MySQL 8+ (#38)
- Added indexes on database columns
- Improved error handling during file upload and file edit
- Added option to add predefined set of meta fields
- Added optional image licensing feature
- PHP 8 compatibility fixes
- Fixed compatibility with recent version of TinyMCE RTE using the callback

MediaManager 0.2.9
====================================
- Fix load modPhpThumb for previews (#15)

MediaManager 0.2.8
====================================
- Fix replacing images used in ContentBlocks fields (#31)
- Add linked resource ID in preview popup (#24)

MediaManager 0.2.7
====================================
- Fix Archive & Replace feature for TV and ContentBlocks field

MediaManager 0.2.6
====================================
- Check file existing on archive and unarchive (#27)
- Delete versions and thumbnails for deleted files (#33)
- Fix setting value if TV not found (#34)

MediaManager 0.2.5
====================================
- Fix after adding images to pages, no link reference getting shown in backend GUI (#24)
- Fix MODX Resource / Elements visibility toggle button not working (#26)
- Fix deleting an image was not successful (#27)
- Fix when opening the preview window on an image, MODX logs some errors (#28)
- Fix available sizes is not being populated with information (#29)

MediaManager 0.2.4
====================================
- Fix thumbnail generation (#15)
- Fix some styling issues (#16)
- Fix category creation (#17)
- Fix tag creation (#18)
- Fix uploading files error (#19)
- Add metadata template (#21)

MediaManager 0.2.3
====================================
- SVG previews are now shown in the mediamanager
- Added system settings for the maximum allowable file upload sizes

MediaManager 0.2.2
====================================
- Replaced JQuery lazyload with native lazyload
- Fixed imagickloaded check and added fallback for pdf previews
- Fixed issue with the mediamanager component height

MediaManager 0.2.1
====================================
- Added custom MIGX renderer "MediaManager.MIGX_Image_Renderer"
- Fixed generated share link
- Fixed bulk delete
- Added image input field for ContentBlocks
- Added support for Redactor 3.0
- Improved search, now searches in both file name and file id columns
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '2f14a4e24daceb9031b71e88460e8c4d',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modNamespace/9a6c2811b2a35b17636de4467692c903.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5eab76ab3e66fbaab8bb566c3115e894',
      'native_key' => 'mediamanager.cleanup_max_age',
      'filename' => 'MODX/Revolution/modSystemSetting/d63087256b56571736b03a9c7b13a2b6.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '629be289504ee40c0938ec0b2e24088c',
      'native_key' => 'mediamanager.cleanup_time',
      'filename' => 'MODX/Revolution/modSystemSetting/2c7211122b89945d607ada7418c8ac03.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '93807846d37607e2700cd726a5176105',
      'native_key' => 'mediamanager.default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/ceac458d48d7e09b39725902d8335e5b.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8500fbdbe3319813d09fe89eab807118',
      'native_key' => 'mediamanager.max_file_size',
      'filename' => 'MODX/Revolution/modSystemSetting/99b441ee13cffeacab4d967694f98bbe.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b3a7606451b10ecaf321f61d206b9a7e',
      'native_key' => 'mediamanager.max_file_size_images',
      'filename' => 'MODX/Revolution/modSystemSetting/f61af60daa610b7614b18e1af0ba6f18.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '603a91822b1d66eb10b40dbcb0d18682',
      'native_key' => '603a91822b1d66eb10b40dbcb0d18682',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/f21bc46937302d87bad7a0c81732aaf4.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '9ed9b86aaaa5fcd39ae8b23bc8ca28ab',
      'native_key' => 'mediamanager',
      'filename' => 'MODX/Revolution/modMenu/73db4df6266783675951badecaba4b70.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '8a2dd191616e7206ad7c0a1e89abcb86',
      'native_key' => 'mediamanager.categories',
      'filename' => 'MODX/Revolution/modMenu/97aa9e728c43349fb93fd1f8e164d1bb.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '14cadbc4896c4047e339da451308405d',
      'native_key' => 'mediamanager.tags',
      'filename' => 'MODX/Revolution/modMenu/6ac4eee3beb6d248ab273565feaaf8fb.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '1308dff67ec421155459caa050aba1ed',
      'native_key' => '1308dff67ec421155459caa050aba1ed',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/70a115452618562546e7c10e116a677b.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'e788e8ec3858f1f70ca5e0bfbea0c161',
      'native_key' => 'e788e8ec3858f1f70ca5e0bfbea0c161',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/76e5989405e8ab0498adb207bd6e0626.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modCategory',
      'guid' => '0ff7f2808c593f5627fee4d4f68e4c94',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modCategory/3a0e197139042aa639870ef7776c058f.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '4c16e61e83cd9017cdc7849ff12ac573',
      'native_key' => '4c16e61e83cd9017cdc7849ff12ac573',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/ef1796fe4e9d0baae0732eac90d7a1e6.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => '6518c6c86f8bd724ba9c0b8fade1a699',
      'native_key' => '6518c6c86f8bd724ba9c0b8fade1a699',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/d5e2bfc46d099bdb675251191223b61a.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'class' => 'xPDO\\Transport\\xPDOScriptVehicle',
      'guid' => 'bbf8d83d0b27f42970fbe66648dd09e2',
      'native_key' => 'bbf8d83d0b27f42970fbe66648dd09e2',
      'filename' => 'xPDO/Transport/xPDOScriptVehicle/1d39171960214f79f176571db9bb1ddd.vehicle',
    ),
  ),
);